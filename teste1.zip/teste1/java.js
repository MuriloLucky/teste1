var nome = "murilo geraldo da motta brasil";
console.log(nome);