var int = 1;
var dec = 1.1;
var resul = int + dec;
console.log(resul);