var idade=15; 
var idadeamigo=16;
var resul = idade - idadeamigo;
console.log(resul+" de diferença de idade");