var gmail = "murilo@gmail.com"
var caractere = "@";

if(gmail.includes(caractere)){
    console.log("gmail valido");
}else{
    console.log("gmail invalido")
}